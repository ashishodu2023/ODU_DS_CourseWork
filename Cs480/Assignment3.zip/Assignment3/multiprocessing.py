import itertools
import time
from concurrent.futures import ThreadPoolExecutor

def read_dictionary(filename):
    with open(filename, 'r') as file:
        words = [line.strip() for line in file]
    return words

# Function to initialize an empty grid
def create_empty_grid(size):
    return [[' ' for _ in range(size)] for _ in range(size)]

# Function to print the crossword grid
def print_grid(grid):
    for row in grid:
        print(''.join(row))

# Function to check if a word fits in a given position
def can_place_word(word, grid, row, col, direction):
    if direction == 'across':
        return col + len(word) <= len(grid[0]) and all(grid[row][col + i] == ' ' or grid[row][col + i] == word[i] for i in range(len(word)))
    else:  # direction == 'down'
        return row + len(word) <= len(grid) and all(grid[row + i][col] == ' ' or grid[row + i][col] == word[i] for i in range(len(word)))

# Function to place a word in the grid
def place_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = word[i]
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = word[i]

# Function to remove a word from the grid
def remove_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = ' '
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = ' '

# Calculate a heuristic score for a word at a given position
def heuristic_score(word, grid, row, col, direction):
    intersections = 0
    if direction == 'across':
        for i in range(len(word)):
            if grid[row][col + i] == word[i]:
                intersections += 1
    else:  # direction == 'down'
        for i in range(len(word)):
            if grid[row + i][col] == word[i]:
                intersections += 1

    # Heuristic score (higher is better)
    return len(word) - intersections

# Implement the AC-3 algorithm for arc consistency
def ac3(csp, queue):
    while queue:
        xi, xj = queue.pop(0)
        if revise(csp, xi, xj):
            if len(csp[xi]) == 0:
                return False
            for xk in csp[xi]:
                if xk != xj:
                    queue.append((xk, xi))
    return True

def revise(csp, xi, xj):
    revised = False
    for x in csp[xi]:
        if not any(satisfies(x, y) for y in csp[xj]):
            csp[xi].remove(x)
            revised = True
    return revised

def satisfies(word1, word2):
    max_length = max(len(word1), len(word2))
    word1 = word1.ljust(max_length, ' ')
    word2 = word2.ljust(max_length, ' ')
    return all(word1[i] == word2[i] or word1[i] == ' ' or word2[i] == ' ' for i in range(max_length))

# Create a refined dictionary
def build_refined_dictionary(dictionary):
    refined_dict = {i: [] for i in range(2, max(map(len, dictionary)) + 1)}

    for word in dictionary:
        length = len(word)
        if length in refined_dict:
            refined_dict[length].append(word)

    return refined_dict

# Create a constraint satisfaction problem (CSP)
def create_csp(refined_dict):
    csp = {}
    for length, words in refined_dict.items():
        csp[length] = {word: set() for word in words}
    for length, words in refined_dict.items():
        for word1 in words:
            for word2 in words:
                if word1 != word2:
                    if has_common_letter(word1, word2):
                        csp[length][word1].add(word2)
    return csp

# Helper function to check if two words have a common letter
def has_common_letter(word1, word2):
    return any(letter1 == letter2 for letter1 in word1 for letter2 in word2)

# Filter the dictionary based on valid words for the CSP
def is_valid_word(word):
    # Define your criteria for a valid word, e.g., check for valid characters
    valid_characters = "abcdefghijklmnopqrstuvwxyz"
    return all(char in valid_characters for char in word)

def prune_words(words, grid, row, col, direction):
    # Prune words that are unlikely to fit based on constraints and intersections
    pruned_words = set()
    for word in words:
        if can_place_word(word, grid, row, col, direction):
            pruned_words.add(word)
    return pruned_words

def forward_check(csp, crossword_grid, word_data, row, col):
    if not word_data:
        return True  # Successfully filled the grid

    for clue, (r, c), data in word_data:
        word_length = data.get("word_length", None)  # Obtain the word_length
        direction = data.get("direction", "across")  # Obtain the direction (default to 'across' if not specified)

        if word_length is None:
            continue  # Skip word data without 'word_length'

        # Prune words that are unlikely to fit
        pruned_words = prune_words(csp[word_length], crossword_grid, r, c, direction)

        if not pruned_words:
            return False  # No valid words left

        for word in pruned_words:
            if direction == "across":
                place_word(word, crossword_grid, r, c, direction)
            else:
                place_word(word, crossword_grid, r, c, direction)

            # Update the CSP for this word placement
            temp_csp = csp.copy()
            temp_csp[word_length].remove(word)

            result = forward_check(temp_csp, crossword_grid, [(clue, (r, c), data) for clue, (r, c), data in word_data if clue != clue], row, col + 1)

            if result:
                return True

            remove_word(word, crossword_grid, r, c, direction)

    return False

def solve_crossword(grid, valid_words, row=0, col=0):
    if row == len(grid):
        return grid  # Successfully filled the grid

    if grid[row][col] == '#':
        # Skip filled cells and move to the next cell
        if col == len(grid[row]) - 1:
            return solve_crossword(grid, valid_words, row + 1, 0)
        else:
            return solve_crossword(grid, valid_words, row, col + 1)

    def thread_solve(direction):
        for length in range(2, len(grid[row]) + 1):
            if length in valid_words:
                for word in valid_words[length]:
                    if can_place_word(word, grid, row, col, direction):
                        place_word(word, grid, row, col, direction)
                        new_valid_words = valid_words.copy()
                        new_valid_words[length] = new_valid_words[length] - {word}

                        if col == len(grid[row]) - 1:
                            result = solve_crossword(grid, new_valid_words, row + 1, 0)
                        else:
                            result = solve_crossword(grid, new_valid_words, row, col + 1)

                        if result:
                            executor.shutdown(False)  # Terminate all other threads
                            return result

                        remove_word(word, grid, row, col, direction)

    # Multithreaded execution
    executor = ThreadPoolExecutor(max_workers=2)
    results = list(executor.map(thread_solve, ['across', 'down']))
    return next((result for result in results if result is not None), None)

# Main function
if __name__ == '__main__':
    crossword_grid = [
        ["#", "#", " ", " ", " "," ", " ", " ", " ", "#","#","#"],
        ["#", "#", " ", "#", "#","#", "#", "#", " ", "#","#"," "],
        ["#", "#", " ", "#", "#","#", "#", "#", " ", "#","#"," "],
        ["#", "#", " ", "#", "#"," ", " ", " ", " ", " ","#"," "],
        ["#", "#", " ", "#", "#","#", "#", " ", "#", "#","#"," "],
        ["#", "#", "#", "#", " ","#", "#", " ", " ", " "," "," "],
        ["#", "#", "#", "#", " ","#", "#", " ", "#", " ","#"," "],
        ["#", " ", "#", " ", " "," ", " ", " ", "#", " ","#","#"],
        ["#", " ", "#", "#", " ","#", "#", " ", "#", " ","#","#"],
        [" ", " ", " ", " ", " "," ", "#", "#", "#", " ","#","#"],
        ["#", " ", "#", "#", " ","#", "#", "#", "#", " ","#","#"]
    ]

    start_time = time.time()
    dictionary = read_dictionary('Words.txt')
    refined_dict = build_refined_dictionary(dictionary)
    valid_words = {length: set(words) for length, words in refined_dict.items()}

    solution = solve_crossword(crossword_grid, valid_words)

    if solution:
        print("Crossword Puzzle:")
        print_grid(solution)
        end_time = time.time() - start_time
        print(f'The total execution time is = {round(end_time, 4)} seconds')
    else:
        print("No solution found.")
