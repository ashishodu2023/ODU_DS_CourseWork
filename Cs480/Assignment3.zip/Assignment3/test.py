import itertools
import time

# Function to read a list of words from a dictionary file
def read_dictionary(filename):
    with open(filename, 'r') as file:
        words = [line.strip() for line in file]
    return words

# Function to initialize an empty grid
def create_empty_grid(size):
    return [[' ' for _ in range(size)] for _ in range(size)]

# Function to print the crossword grid
def print_grid(grid):
    for row in grid:
        print(''.join(row))

# Function to check if a word fits in a given position
def can_place_word(word, grid, row, col, direction):
    if direction == 'across':
        return col + len(word) <= len(grid[0]) and all(
            grid[row][col + i] == ' ' or grid[row][col + i] == word[i] for i in range(len(word)))
    else:  # direction == 'down'
        return row + len(word) <= len(grid) and all(
            grid[row + i][col] == ' ' or grid[row + i][col] == word[i] for i in range(len(word)))

# Function to place a word in the grid
def place_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = word[i]
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = word[i]

# Function to remove a word from the grid
def remove_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = ' '
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = ' '

# Calculate a heuristic score for a word at a given position
def heuristic_score(word, grid, row, col, direction):
    intersections = 0
    if direction == 'across':
        for i in range(len(word)):
            if grid[row][col + i] == word[i]:
                intersections += 1
    else:  # direction == 'down'
        for i in range(len(word)):
            if grid[row + i][col] == word[i]:
                intersections += 1

    # Heuristic score (higher is better)
    return len(word) - intersections

# Function to generate the crossword
def generate_crossword(grid, words, word_data, row=0, col=0):
    if not word_data:
        print_grid(grid)  # Print the grid when all words are placed
        return grid

    for i in range(len(word_data)):
        clue, (r, c) = word_data[i]
        word_length = len(clue)
        valid_words = [word for word in words if len(word) == word_length]

        for word in valid_words:
            if can_place_word(word, grid, r, c, 'across'):
                place_word(word, grid, r, c, 'across')
                print_grid(grid)  # Print the grid after placing a word
                print()
                remaining_words = words - {word}
                result = generate_crossword(
                    grid, remaining_words, word_data[i + 1:], row, col)
                if result is not None:
                    return result
                remove_word(word, grid, r, c, 'across')

            if can_place_word(word, grid, r, c, 'down'):
                place_word(word, grid, r, c, 'down')
                print_grid(grid)  # Print the grid after placing a word
                print()
                remaining_words = words - {word}
                result = generate_crossword(
                    grid, remaining_words, word_data[i + 1:], row, col)
                if result is not None:
                    return result
                remove_word(word, grid, r, c, 'down')

    return None

# Main function
if __name__ == '__main__':
    crossword_grid = [
        ["#", "#", " ", " ", " ", " ", " ", " ", " ", "#", "#", "#"],
        ["#", "#", " ", "#", "#", "#", "#", "#", " ", "#", "#", " "],
        ["#", "#", " ", "#", "#", "#", "#", "#", " ", "#", "#", " "],
        ["#", "#", " ", "#", "#", " ", " ", " ", " ", " ", "#", " "],
        ["#", "#", " ", "#", "#", "#", "#", " ", "#", "#", "#", " "],
        ["#", "#", "#", "#", " ", "#", "#", " ", " ", " ", " ", " "],
        ["#", "#", "#", "#", " ", "#", "#", " ", "#", " ", "#", " "],
        ["#", " ", "#", " ", " ", " ", " ", " ", "#", " ", "#", "#"],
        ["#", " ", "#", "#", " ", "#", "#", " ", "#", " ", "#", "#"],
        [" ", " ", " ", " ", " ", " ", "#", "#", "#", " ", "#", "#"],
        ["#", " ", "#", "#", " ", "#", "#", "#", "#", " ", "#", "#"],
    ]

    word_data = [
        ("1ACROSS", [0, 2]),
        ("1DOWN", [0, 2]),
        ("2DOWN", [0, 8]),
        ("3DOWN", [1, 11]),
        ("4ACROSS", [3, 5]),
        ("5DOWN", [3, 7]),
        ("6DOWN", [5, 4]),
        ("7ACROSS", [5, 7]),
        ("7DOWN", [5, 7]),
        ("8DOWN", [5, 9]),
        ("9DOWN", [7, 1]),
        ("10ACROSS", [7, 3]),
        ("11ACROSS", [0, 0])
    ]

    start_time = time.time()
    dictionary = read_dictionary('Words.txt')
    
    solution = generate_crossword(crossword_grid, set(dictionary), word_data)

    if solution:
        print("Crossword Puzzle:")
        print_grid(solution)
        end_time = (time.time() - start_time)
        print(f'The total execution time is = {round(end_time, 4)} seconds')
    else:
        print("No solution found.")
