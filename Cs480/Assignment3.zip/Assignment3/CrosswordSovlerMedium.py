import itertools
import time

# Function to read a list of words from a dictionary file


def read_dictionary(filename):
    with open(filename, 'r') as file:
        words = [line.strip() for line in file]
    return words

# Function to initialize an empty grid


def create_empty_grid(size):
    return [[' ' for _ in range(size)] for _ in range(size)]

# Function to print the crossword grid


def print_grid(grid):
    for row in grid:
        print(''.join(row))

# Function to check if a word fits in a given position


def can_place_word(word, grid, row, col, direction):
    if direction == 'across':
        return col + len(word) <= len(grid[0]) and all(grid[row][col + i] == ' ' or grid[row][col + i] == word[i] for i in range(len(word)))
    else:  # direction == 'down'
        return row + len(word) <= len(grid) and all(grid[row + i][col] == ' ' or grid[row + i][col] == word[i] for i in range(len(word)))

# Function to place a word in the grid


def place_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = word[i]
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = word[i]

# Function to remove a word from the grid


def remove_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = ' '
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = ' '

# Calculate a heuristic score for a word at a given position


def heuristic_score(word, grid, row, col, direction):
    intersections = 0
    if direction == 'across':
        for i in range(len(word)):
            if grid[row][col + i] == word[i]:
                intersections += 1
    else:  # direction == 'down'
        for i in range(len(word)):
            if grid[row + i][col] == word[i]:
                intersections += 1

    # Heuristic score (higher is better)
    return len(word) - intersections

# Implement the AC-3 algorithm for arc consistency


def ac3(csp, queue):
    while queue:
        xi, xj = queue.pop(0)
        if revise(csp, xi, xj):
            if len(csp[xi]) == 0:
                return False
            for xk in csp[xi]:
                if xk != xj:
                    queue.append((xk, xi))
    return True


def revise(csp, xi, xj):
    revised = False
    for x in csp[xi]:
        if not any(satisfies(x, y) for y in csp[xj]):
            csp[xi].remove(x)
            revised = True
    return revised


def satisfies(word1, word2):
    max_length = max(len(word1), len(word2))
    word1 = word1.ljust(max_length, ' ')
    word2 = word2.ljust(max_length, ' ')
    return all(word1[i] == word2[i] or word1[i] == ' ' or word2[i] == ' ' for i in range(max_length))


# Modified crossword generation function
def generate_crossword(grid, words, word_data, row=0, col=0, depth=0, max_depth=50):
    if not word_data:
        return grid

    if depth > max_depth:
        return None

    for clue, (r, c), data in word_data:
        word_length = data["word_length"]
        word = [w for w in words if len(w) == word_length and all(
            grid[r][c + i] == ' ' or grid[r][c + i] == w[i] for i in range(len(w)))]

        if word:
            word = word[0]
            if can_place_word(word, grid, r, c, 'across'):
                place_word(word, grid, r, c, 'across')
            else:
                place_word(word, grid, r, c, 'down')

            result = generate_crossword(grid, words - {word}, [(clue, (r, c), data) for clue, (
                r, c), data in word_data if clue != clue], row, col, depth + 1, max_depth)

            if result is not None:
                return result

            remove_word(word, grid, r, c, 'across')

    return None

# Create a refined dictionary


def build_refined_dictionary(dictionary):
    refined_dict = {i: [] for i in range(2, max(map(len, dictionary)) + 1)}

    for word in dictionary:
        length = len(word)
        if length in refined_dict:
            refined_dict[length].append(word)

    return refined_dict


# Create a constraint satisfaction problem (CSP)
def create_csp(refined_dict):
    csp = {}
    for length, words in refined_dict.items():
        csp[length] = {word: set() for word in words}
    for length, words in refined_dict.items():
        for word1 in words:
            for word2 in words:
                if word1 != word2:
                    if has_common_letter(word1, word2):
                        csp[length][word1].add(word2)
    return csp


# Helper function to check if two words have a common letter
def has_common_letter(word1, word2):
    return any(letter1 == letter2 for letter1 in word1 for letter2 in word2)

# Filter the dictionary based on valid words for the CSP


def is_valid_word(word):
    # Define your criteria for a valid word, e.g., check for valid characters
    valid_characters = "abcdefghijklmnopqrstuvwxyz"
    return all(char in valid_characters for char in word)


# Main function
if __name__ == '__main__':
    crossword_grid = [
        ["#", "#", " ", " ", " ", " ", " ", " ", " ", "#", "#", "#"],
        ["#", "#", " ", "#", "#", "#", "#", "#", " ", "#", "#", " "],
        ["#", "#", " ", "#", "#", "#", "#", "#", " ", "#", "#", " "],
        ["#", "#", " ", "#", "#", " ", " ", " ", " ", " ", "#", " "],
        ["#", "#", " ", "#", "#", "#", "#", " ", "#", "#", "#", " "],
        ["#", "#", "#", "#", " ", "#", "#", " ", " ", " ", " ", " "],
        ["#", "#", "#", "#", " ", "#", "#", " ", "#", " ", "#", " "],
        ["#", " ", "#", " ", " ", " ", " ", " ", "#", " ", "#", "#"],
        ["#", " ", "#", "#", " ", "#", "#", " ", "#", " ", "#", "#"],
        [" ", " ", " ", " ", " ", " ", "#", "#", "#", " ", "#", "#"],
        ["#", " ", "#", "#", " ", "#", "#", "#", "#", " ", "#", "#"],
    ]

    word_data = [
        ("1ACROSS", [0, 2], {"word_length": 7}),
        ("1DOWN", [0, 2], {"word_length": 5}),
        ("2DOWN", [0, 8], {"word_length": 4}),
        ("3DOWN", [1, 11], {"word_length": 6}),
        ("4ACROSS", [3, 5], {"word_length": 5}),
        # ("5ACROSS", [3, 7]),
        ("5DOWN", [3, 7], {"word_length": 6}),
        ("6DOWN", [5, 4], {"word_length": 6}),
        ("7ACROSS", [5, 7], {"word_length": 5}),
        ("7DOWN", [5, 7], {"word_length": 4}),
        # ("8ACROSS", [5, 9]),
        ("8DOWN", [5, 9], {"word_length": 6}),
        ("9DOWN", [7, 1], {"word_length": 4}),
        ("10ACROSS", [7, 3], {"word_length": 5}),
        ("11ACROSS", [0, 0], {"word_length": 6})
    ]
    start_time = time.time()
    dictionary = read_dictionary('Words.txt')
    refined_dict = build_refined_dictionary(dictionary)
    valid_words = set(word for words_list in refined_dict.values()
                      for word in words_list)
    csp = {word: set() for word in valid_words}

# Populate the CSP with constraints
    for length, words in refined_dict.items():
        for word1 in words:
            for word2 in words:
                if word1 != word2:
                    # Replace this with your specific constraint satisfaction function
                    if satisfies(word1, word2):
                        csp[word1].add(word2)

    queue = [(xi, xj) for xi in csp for xj in csp[xi]]
    ac3(csp, queue)

    # Use only words that satisfy the CSP
    filtered_dictionary = {
        word for word in dictionary if is_valid_word(word) and word in csp}

    solution = generate_crossword(
        crossword_grid, filtered_dictionary, word_data, max_depth=100)

    if solution:
        print("Crossword Puzzle:")
        print_grid(solution)
        end_time = (time.time() - start_time)
        print(f'The total execution time is = {round(end_time,4)} seconds')
    else:
        print("No solution found.")
