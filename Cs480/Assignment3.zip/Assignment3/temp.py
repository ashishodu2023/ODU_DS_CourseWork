import itertools
import time
import requests  # Import the requests library

# Function to read a list of words from a dictionary URL
"""
def read_dictionary(url):
    response = requests.get(url)
    if response.status_code == 200:
        words = response.text.split('\n')
        return [word.strip() for word in words]
    else:
        raise Exception(f"Failed to fetch words from {url}")
"""
def read_dictionary(filename):
    with open(filename, 'r') as file:
        words = [line.strip() for line in file]
    return words

# Function to initialize an empty grid
def create_empty_grid(size):
    return [[' ' for _ in range(size)] for _ in range(size)]

# Function to print the crossword grid
def print_grid(grid):
    for row in grid:
        print(''.join(row))

# Function to check if a word fits in a given position
def can_place_word(word, grid, row, col, direction):
    if direction == 'across':
        return col + len(word) <= len(grid[0]) and all(
            grid[row][col + i] == ' ' or grid[row][col + i] == word[i] for i in range(len(word)))
    else:  # direction == 'down'
        return row + len(word) <= len(grid) and all(
            grid[row + i][col] == ' ' or grid[row + i][col] == word[i] for i in range(len(word)))

# Function to place a word in the grid
def place_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = word[i]
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = word[i]

# Function to remove a word from the grid
def remove_word(word, grid, row, col, direction):
    if direction == 'across':
        for i in range(len(word)):
            grid[row][col + i] = ' '
    else:  # direction == 'down'
        for i in range(len(word)):
            grid[row + i][col] = ' '

# Calculate a heuristic score for a word at a given position
def heuristic_score(word, grid, row, col, direction):
    intersections = 0
    if direction == 'across':
        for i in range(len(word)):
            if grid[row][col + i] == word[i]:
                intersections += 1
    else:  # direction == 'down'
        for i in range(len(word)):
            if grid[row + i][col] == word[i]:
                intersections += 1

    # Heuristic score (higher is better)
    return len(word) - intersections

# Add the revise function
def revise(csp, xi, xj):
    revised = False
    words_to_remove = []
    for x in csp[xi]:
        if xj in csp and not any(satisfies(x, y) for y in csp[xj]):
            words_to_remove.append(x)
            revised = True
    for word in words_to_remove:
        csp[xi].remove(word)
    return revised


def satisfies(x, y, csp):
    max_length = max(len(x), len(y))
    x = x.ljust(max_length, ' ')
    y = y.ljust(max_length, ' ')
    return all(x[i] == y[i] or x[i] == ' ' or y[i] == ' ' for i in range(max_length))

def ac3(csp, queue):
    while queue:
        xi, xj = queue.pop()
        if revise(csp, xi, xj):
            if len(csp[xi]) == 0:
                return False
            for xk in csp[xi]:
                if xk != xj:
                    queue.append((xk, xi))
    return True

# Modified crossword generation function
def generate_crossword(grid, words, word_data, row=0, col=0):
    if not word_data:
        return grid

    for clue, (r, c) in word_data:
        word_length = len(clue)
        valid_words = [word for word in words if len(word) == word_length]

        for word in valid_words:
            if can_place_word(word, grid, r, c, 'across'):
                place_word(word, grid, r, c, 'across')
                print_grid(grid)  # Print the state of the grid after placing the word
            else:
                place_word(word, grid, r, c, 'down')
                print_grid(grid)  # Print the state of the grid after placing the word

            result = generate_crossword(grid, words - {word}, [
                (clue, (r, c)) for clue, (r, c) in word_data], row, col)

            if result is not None:
                return result

            remove_word(word, grid, r, c, 'across')
            print_grid(grid)  # Print the state of the grid after removing the word

    return None



# Create a refined dictionary
def build_refined_dictionary(dictionary):
    refined_dict = {i: [] for i in range(2, max(map(len, dictionary)) + 1)}

    for word in dictionary:
        length = len(word)
        if length in refined_dict:
            refined_dict[length].append(word)

    return refined_dict

# Create a constraint satisfaction problem (CSP)
def create_csp(refined_dict):
    csp = {}
    for length, words in refined_dict.items():
        csp[length] = {word: set() for word in words}
    for length, words in refined_dict.items():
        for word1 in words:
            for word2 in words:
                if word1 != word2:
                    if has_common_letter(word1, word2):
                        csp[length][word1].add(word2)
    return csp

# Helper function to check if two words have a common letter
def has_common_letter(word1, word2):
    return any(letter1 == letter2 for letter1 in word1 for letter2 in word2)

# Filter the dictionary based on valid words for the CSP
def is_valid_word(word):
    # Define your criteria for a valid word, e.g., check for valid characters
    valid_characters = "abcdefghijklmnopqrstuvwxyz"
    return all(char in valid_characters for char in word)

# Main function
if __name__ == '__main__':
    crossword_grid = [
        ["#", "#", " ", " ", " ", " ", " ", " ", " ", "#", "#", "#"],
        ["#", "#", " ", "#", "#", "#", "#", "#", " ", "#", "#", " "],
        ["#", "#", " ", "#", "#", "#", "#", "#", " ", "#", "#", " "],
        ["#", "#", " ", "#", "#", " ", " ", " ", " ", " ", "#", " "],
        ["#", "#", " ", "#", "#", "#", "#", " ", "#", "#", "#", " "],
        ["#", "#", "#", "#", " ", "#", "#", " ", " ", " ", " ", " "],
        ["#", "#", "#", "#", " ", "#", "#", " ", "#", " ", "#", " "],
        ["#", " ", "#", " ", " ", " ", " ", " ", "#", " ", "#", "#"],
        ["#", " ", "#", "#", " ", "#", "#", " ", "#", " ", "#", "#"],
        [" ", " ", " ", " ", " ", " ", "#", "#", "#", " ", "#", "#"],
        ["#", " ", "#", "#", " ", "#", "#", "#", "#", " ", "#", "#"],
    ]

    word_data = [
        ("1ACROSS", [0, 2]),
        ("1DOWN", [0, 2]),
        ("2DOWN", [0, 8]),
        ("3DOWN", [1, 11]),
        ("4ACROSS", [3, 5]),
        ("5DOWN", [3, 7]),
        ("6DOWN", [5, 4]),
        ("7ACROSS", [5, 7]),
        ("7DOWN", [5, 7]),
        ("8DOWN", [5, 9]),
        ("9DOWN", [7, 1]),
        ("10ACROSS", [7, 3]),
        ("11ACROSS", [0, 0])
    ]
    start_time = time.time()
    #url = 'https://raw.githubusercontent.com/Rajil1213/cs50AI/master/Week3/crossword/data/words2.txt'
    #dictionary = read_dictionary(url)
    dictionary = read_dictionary('Words.txt')
    refined_dict = build_refined_dictionary(dictionary)
    valid_words = set(word for words_list in refined_dict.values()
                      for word in words_list)
  
    csp = create_csp(refined_dict)

    queue = set((xi, xj) for xi in csp for xj in csp[xi])
    
    
    print(ac3(csp, queue))

    """
    # Use only words that satisfy the CSP
    filtered_dictionary = {
        word for word in dictionary if is_valid_word(word) and word in csp}

    solution = generate_crossword(
        crossword_grid, filtered_dictionary, word_data)

    if solution:
        print("Crossword Puzzle:")
        print_grid(solution)
        end_time = (time.time() - start_time)
        print(f'The total execution time is = {round(end_time, 4)} seconds')
    else:
        print("No solution found.")
        end_time = (time.time() - start_time)
        print(f'The total execution time is = {round(end_time, 4)} seconds')
    """